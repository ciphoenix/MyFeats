﻿using BlueprintCore.Actions.Builder;
using BlueprintCore.Blueprints.CustomConfigurators.Classes;
using BlueprintCore.Blueprints.References;
using BlueprintCore.Utils.Types;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Components;
using Kingmaker.UnitLogic.Mechanics.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlueprintCore.Actions.Builder.ContextEx;

namespace MyFeats.Feats
{
    internal class CombatConditioning
    {
        public static void Configure()
        {
            Main.Log.Log("Calling the Configure Method");
            Main.AllMeleeAndRangedCategories.Aggregate(
            FeatureConfigurator.New(Feature, FeatureGuid)
                    .SetDisplayName("CombatConditioning.FeatureName")
                    .SetDescription("CombatConditioning.FeatureDescription")
                    .SetHideInUI(true)
                    .AddRecalculateOnStatChange(stat: StatType.Constitution)
                    .AddComponent(new MyScalingSpellsPerDay
                    {
                        Stat = StatType.Constitution,
                        MinLevel = 1,
                        MaxLevel = 10,
                        Multiplier = 1
                    })
                    .AddReplaceStatBaseAttribute(baseAttributeReplacement: StatType.Constitution, replaceIfHigher: true, replaceMod: Kingmaker.UnitLogic.Buffs.BonusMod.AsIs, targetStat: StatType.AC)
                    .AddComponent(new AttackStatReplacement
                    {
                        ReplacementStat = StatType.Constitution, // swap for the player's choice
                        CheckWeaponTypes = false           // skip the weapon-type restriction entirely
                    })
                    .AddComponent(new AddTargetBeforeAttackRollTrigger
                    {
                        ActionsOnAttacker = ActionsBuilder.New()
                    .ApplyBuff(buff: MyProtectiveLuckBuff.FeatureGuid, durationValue: ContextDuration.Fixed(1, DurationRate.Rounds))
                    .Build()
                    })
                    .AddMaxDexBonusIncrease(contextBonus: ContextValues.Rank(), checkCategory: false, useContextInstead: true)
                    .AddFortification(bonus: 100)
                    .AddModifyD20(takeBest: true, rollsAmount: 3, rule: RuleType.All, rollCondition: ModifyD20.RollConditionType.None, savingThrowType: FlaggedSavingThrowType.All)
                    .AddContextStatBonus(stat: StatType.AdditionalCMB, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.AdditionalCMD, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Speed, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveWill, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveReflex, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Initiative, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveFortitude, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.HitPoints, value: ContextValues.Rank())
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Normal, additionalMultiplier: 1)
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Touch, additionalMultiplier: 1)
                    .AddCriticalConfirmationBonus(value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.BonusCasterLevel, value: ContextValues.Rank())
                    .AddContextRankConfig(ContextRankConfigs.StatBonus(StatType.Constitution).WithMultiplyByModifierProgression(1))
                    .AddWeaponCriticalEdgeIncreaseStackable(value: 2)
                    .AddFeatureOnApply(feature: MagicalAffinityCon.FeatureGuid)
                    .AddFeatureOnApply(feature: MnemonicDevice.FeatureGuid)
                    .AddIncreaseResourcesByClass(characterClass: "42a455d9ec1ad924d889272429eb8391", resource: "066ac4b762e32be4b953703174ed925c", stat: StatType.Constitution)
                    .AddPrerequisiteNoFeature(feature: CombatAnalysis.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatAvoidance.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatInsight.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatProwess.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatPersonality.FeatureGuid),
            (configurator, category) => configurator.AddComponent(new WeaponTypeDamageStatReplacement
            {
                Stat = StatType.Constitution,
                Category = category,
                OnlyOneHanded = false,
                TwoHandedBonus = true
            })
    )
                    .Configure();
        }

        internal static readonly string Feature = "CombatConditioning";
        internal static readonly string FeatureName = "Combat Conditioning";
        internal static readonly string FeatureGuid = "1C4F8A9C-DD22-45A6-80AF-6FBA55A80C6D";
        internal static readonly string FeatureDescription = "You can feel the flow of the battle and your body is conditioned to take on any attack";
    }
}

