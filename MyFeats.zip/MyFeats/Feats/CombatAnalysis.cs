﻿using BlueprintCore.Actions.Builder;
using BlueprintCore.Blueprints.CustomConfigurators.Classes;
using BlueprintCore.Utils.Types;
using Kingmaker.Blueprints.Classes.Spells;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Components;
using Kingmaker.UnitLogic.Mechanics.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlueprintCore.Actions.Builder.ContextEx;

namespace MyFeats.Feats
{
    internal class CombatAnalysis
    {
        public static void Configure()
        {
            Main.Log.Log("Calling the Configure Method");
            Main.AllMeleeAndRangedCategories.Aggregate(
            FeatureConfigurator.New(Feature, FeatureGuid)
                    .SetDisplayName("CombatAnalysis.FeatureName")
                    .SetDescription("CombatAnalysis.FeatureDescription")
                    .SetHideInUI(true)
                    .AddRecalculateOnStatChange(stat: StatType.Intelligence)
                    .AddComponent(new MyScalingSpellsPerDay
                    {
                        Stat = StatType.Intelligence,
                        MinLevel = 1,
                        MaxLevel = 10,
                        Multiplier = 1
                    })
                    .AddReplaceStatBaseAttribute(baseAttributeReplacement: StatType.Intelligence, replaceIfHigher: true, replaceMod: Kingmaker.UnitLogic.Buffs.BonusMod.AsIs, targetStat: StatType.AC)
                    .AddComponent(new AttackStatReplacement
                    {
                        ReplacementStat = StatType.Intelligence, // swap for the player's choice
                        CheckWeaponTypes = false           // skip the weapon-type restriction entirely
                    })
                    .AddComponent(new AddTargetBeforeAttackRollTrigger
                    {
                        ActionsOnAttacker = ActionsBuilder.New()
                    .ApplyBuff(buff: MyProtectiveLuckBuff.FeatureGuid, durationValue: ContextDuration.Fixed(1, DurationRate.Rounds))
                    .Build()
                    })
                    .AddMaxDexBonusIncrease(contextBonus: ContextValues.Rank(), checkCategory: false, useContextInstead: true)
                    .AddFortification(bonus: 100)
                    .AddModifyD20(takeBest: true, rollsAmount: 3, rule: RuleType.All, rollCondition: ModifyD20.RollConditionType.None, savingThrowType: FlaggedSavingThrowType.All)
                    .AddContextStatBonus(stat: StatType.AdditionalCMB, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.AdditionalCMD, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Speed, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveWill, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveReflex, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveFortitude, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.HitPoints, value: ContextValues.Rank())
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Normal, additionalMultiplier: 1)
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Touch, additionalMultiplier: 1)
                    .AddCriticalConfirmationBonus(value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Initiative, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.BonusCasterLevel, value: ContextValues.Rank())
                    .AddIncreaseSpellContextDescriptorDC(descriptor: SpellDescriptor.Hex, value: ContextValues.Rank())
                    .AddIncreaseAllSpellsDC(value: ContextValues.Rank())
                    .AddSpellPenetrationBonus(value: ContextValues.Rank())
                    .AddContextRankConfig(ContextRankConfigs.StatBonus(StatType.Intelligence).WithMultiplyByModifierProgression(1))
                    .AddWeaponCriticalEdgeIncreaseStackable(value: 2)
                    .AddFeatureOnApply(feature: MagicalAffinityInt.FeatureGuid)
                    .AddFeatureOnApply(feature: MnemonicDevice.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatAvoidance.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatConditioning.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatInsight.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatProwess.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatPersonality.FeatureGuid), (configurator, category) => configurator.AddComponent(new WeaponTypeDamageStatReplacement
                    {
                        Stat = StatType.Intelligence,
                        Category = category,
                        OnlyOneHanded = false,
                        TwoHandedBonus = true
                    })
    )
                    .Configure();
        }

        internal static readonly string Feature = "CombatAnalysis";
        internal static readonly string FeatureName = "Combat Analysis";
        internal static readonly string FeatureGuid = "15A12D7F-161A-48F5-8766-1C135018438E";
        internal static readonly string FeatureDescription = "Your analytic mind makes you see the enemy's moves before they make them";
    }
}

