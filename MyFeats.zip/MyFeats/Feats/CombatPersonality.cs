﻿using BlueprintCore.Actions.Builder;
using BlueprintCore.Actions.Builder.ContextEx;
using BlueprintCore.Blueprints.CustomConfigurators.Classes;
using BlueprintCore.Blueprints.CustomConfigurators.UnitLogic.Buffs;
using BlueprintCore.Blueprints.References;
using BlueprintCore.Utils.Types;
using Kingmaker.Blueprints.Classes.Spells;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic.FactLogic;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Components;
using Kingmaker.UnitLogic.Mechanics.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFeats.Feats
{
    public class CombatPersonality
    {
        public static void Configure()
        {
            Main.Log.Log("Calling the Configure Method");
            Main.AllMeleeAndRangedCategories.Aggregate(
                FeatureConfigurator.New(Feature, FeatureGuid)
                    .SetDisplayName("CombatPersonality.FeatureName")
                    .SetDescription("CombatPersonality.FeatureDescription")
                    .SetHideInUI(true)
                    .AddRecalculateOnStatChange(stat: StatType.Charisma)
                    .AddComponent(new MyScalingSpellsPerDay
                    {
                        Stat = StatType.Charisma,
                        MinLevel = 1,
                        MaxLevel = 10,
                        Multiplier = 1
                    })
                    .AddReplaceStatBaseAttribute(baseAttributeReplacement: StatType.Charisma, replaceIfHigher: true, replaceMod: Kingmaker.UnitLogic.Buffs.BonusMod.AsIs, targetStat: StatType.AC)
                    .AddComponent(new AttackStatReplacement
                    {
                        ReplacementStat = StatType.Charisma,
                        CheckWeaponTypes = false
                    })
                    .AddComponent(new AddTargetBeforeAttackRollTrigger
                    {
                        ActionsOnAttacker = ActionsBuilder.New()
                    .ApplyBuff(buff: MyProtectiveLuckBuff.FeatureGuid, durationValue: ContextDuration.Fixed(1, DurationRate.Rounds))
                    .Build()
                    })
                    .AddMaxDexBonusIncrease(contextBonus: ContextValues.Rank(), checkCategory: false, useContextInstead: true)
                    .AddFortification(bonus: 100)
                    .AddModifyD20(takeBest: true, rollsAmount: 3, rule: RuleType.All, rollCondition: ModifyD20.RollConditionType.None, savingThrowType: FlaggedSavingThrowType.All)
                    .AddContextStatBonus(stat: StatType.AdditionalCMB, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.AdditionalCMD, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Speed, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveWill, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveReflex, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveFortitude, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Initiative, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.HitPoints, value: ContextValues.Rank())
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Normal, additionalMultiplier: 1)
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Touch, additionalMultiplier: 1)
                    .AddCriticalConfirmationBonus(value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.BonusCasterLevel, value: ContextValues.Rank())
                    .AddIncreaseSpellContextDescriptorDC(descriptor: SpellDescriptor.Hex, value: ContextValues.Rank())
                    .AddIncreaseAllSpellsDC(value: ContextValues.Rank())
                    .AddSpellPenetrationBonus(value: ContextValues.Rank())
                    .AddContextRankConfig(ContextRankConfigs.StatBonus(StatType.Charisma).WithMultiplyByModifierProgression(1))
                    .AddWeaponCriticalEdgeIncreaseStackable(value: 2)
                    .AddFeatureOnApply(feature: MagicalAffinityCha.FeatureGuid)
                    .AddFeatureOnApply(feature: MnemonicDevice.FeatureGuid)
                    .AddIncreaseResourcesByClass(characterClass: "bfa11238e7ae3544bbeb4d0b92e897ec", resource: "3683d1af071c1744185ff93cba9db10b", stat: StatType.Charisma)
                    .AddIncreaseResourcesByClass(characterClass: "bfa11238e7ae3544bbeb4d0b92e897ec", resource: "5e2bba3e07c37be42909a12945c27de7", stat: StatType.Charisma)
                    .AddPrerequisiteNoFeature(feature: CombatAnalysis.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatAvoidance.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatConditioning.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatInsight.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatProwess.FeatureGuid),
                (configurator, category) => configurator.AddComponent(new WeaponTypeDamageStatReplacement
                {
                    Stat = StatType.Charisma,
                    Category = category,
                    OnlyOneHanded = false,
                    TwoHandedBonus = true
                })
            ).Configure();
            
        }

        internal static readonly string Feature = "CombatPersonality";
        internal static readonly string FeatureName = "Combat Personality";
        internal static readonly string FeatureGuid = "1A1A6844-7D67-407F-93DC-CA48B999DAD8";
        internal static readonly string FeatureDescription = "You can avoid attacks via sheer personality";
    }
}
