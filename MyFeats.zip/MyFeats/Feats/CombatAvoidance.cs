﻿using BlueprintCore.Actions.Builder;
using BlueprintCore.Blueprints.CustomConfigurators.Classes;
using BlueprintCore.Utils.Types;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.EntitySystem.Stats;
using Kingmaker.RuleSystem.Rules;
using Kingmaker.UnitLogic.Mechanics;
using Kingmaker.UnitLogic.Mechanics.Components;
using Kingmaker.UnitLogic.Mechanics.Properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlueprintCore.Actions.Builder.ContextEx;

namespace MyFeats.Feats
{
    internal class CombatAvoidance
    {
        public static void Configure()
        {
            Main.Log.Log("Calling the Configure Method");
            Main.AllMeleeAndRangedCategories.Aggregate(
            FeatureConfigurator.New(Feature, FeatureGuid)
                    .SetDisplayName("CombatAvoidance.FeatureName")
                    .SetDescription("CombatAvoidance.FeatureDescription")
                    .SetHideInUI(true)
                    .AddRecalculateOnStatChange(stat: StatType.Dexterity)
                    .AddMaxDexBonusIncrease(contextBonus: ContextValues.Rank(), checkCategory: false, useContextInstead: true)
                    .AddFortification(bonus: 100)
                    .AddComponent(new AddTargetBeforeAttackRollTrigger
                    {
                        ActionsOnAttacker = ActionsBuilder.New()
                    .ApplyBuff(buff: MyProtectiveLuckBuff.FeatureGuid, durationValue: ContextDuration.Fixed(1, DurationRate.Rounds))
                    .Build()
                    })
                    .AddModifyD20(takeBest: true, rollsAmount: 3, rule: RuleType.All, rollCondition: ModifyD20.RollConditionType.None, savingThrowType: FlaggedSavingThrowType.All)
                    .AddContextStatBonus(stat: StatType.AdditionalCMB, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.AdditionalCMD, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Speed, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveWill, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveReflex, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.SaveFortitude, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.Initiative, value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.HitPoints, value: ContextValues.Rank())
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Normal, additionalMultiplier: 1)
                    .AddAttackTypeCriticalMultiplierIncrease(type: Kingmaker.Enums.WeaponRangeType.Touch, additionalMultiplier: 1)
                    .AddCriticalConfirmationBonus(value: ContextValues.Rank())
                    .AddContextStatBonus(stat: StatType.BonusCasterLevel, value: ContextValues.Rank())
                    .AddContextRankConfig(ContextRankConfigs.StatBonus(StatType.Dexterity).WithMultiplyByModifierProgression(1))
                    .AddWeaponCriticalEdgeIncreaseStackable(value: 2)
                    .AddFeatureOnApply(feature: MagicalAffinityDex.FeatureGuid)
                    .AddFeatureOnApply(feature: MnemonicDevice.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatAnalysis.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatConditioning.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatInsight.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatProwess.FeatureGuid)
                    .AddPrerequisiteNoFeature(feature: CombatPersonality.FeatureGuid), (configurator, category) => configurator.AddComponent(new WeaponTypeDamageStatReplacement
                    {
                        Stat = StatType.Dexterity,
                        Category = category,
                        OnlyOneHanded = false,
                        TwoHandedBonus = true
                    })
    )
                    .Configure();
        }

        internal static readonly string Feature = "CombatAvoidance";
        internal static readonly string FeatureName = "Combat Avoidance";
        internal static readonly string FeatureGuid = "D58F87BE-D4EC-4A9D-807E-E4BE05969BB5";
        internal static readonly string FeatureDescription = "They cannot hit you if they cannot get to you. You weave around the battlefield at incredible speeds";
    }
}

