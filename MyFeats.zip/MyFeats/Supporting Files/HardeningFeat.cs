﻿using BlueprintCore.Blueprints.CustomConfigurators.Classes;
using BlueprintCore.Utils.Types;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Enums.Damage;
using Kingmaker.UnitLogic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Kingmaker.Blueprints;

namespace MyFeats.Feats
{
    public class HardeningFeat
    {
        public static void Configure()
        {
            Main.Log.Log("Calling the Configure Method");
            FeatureConfigurator.New(Feature, FeatureGuid)
                    .SetDisplayName("HardeningFeat.FeatureName")
                    .SetDescription("HardeningFeat.FeatureDescription")
                    .SetHideInUI(true)
                    .AddDamageResistanceHardness(value: ContextValues.Rank())
                    .AddDamageResistancePhysical(value: ContextValues.Rank())
                    .AddContextRankConfig(ContextRankConfigs.CharacterLevel().WithMultiplyByModifierProgression(1))
                    .Configure();
        }

        internal static readonly string Feature = "HardeningFeat";
        internal static readonly string FeatureName = "Hardening";
        internal static readonly string FeatureGuid = "6DE02BC9-4303-407A-A284-5FA1D9E4C9C1";
        internal static readonly string FeatureDescription = "Your skin becomes tougher and more impervious to damage";
    }
}
