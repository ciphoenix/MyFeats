﻿using BlueprintCore.Blueprints.CustomConfigurators.Classes;
using BlueprintCore.Blueprints.References;
using BlueprintCore.Utils.Types;
using Kingmaker.Blueprints.Classes;
using Kingmaker.Blueprints.Classes.Spells;
using Kingmaker.Designers.Mechanics.Facts;
using Kingmaker.Enums.Damage;
using Kingmaker.UnitLogic.Abilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyFeats.Patches;

namespace MyFeats.Feats
{
    public class MnemonicDevice
    {
        private static readonly Metamagic[] AlwaysOn =
        {
            Metamagic.Reach, Metamagic.Piercing, Metamagic.Intensified,
            Metamagic.Heighten, Metamagic.Bolstered, Metamagic.Empower,
            Metamagic.Extend, Metamagic.Selective,
            Metamagic.Maximize
        };

        private static readonly AutoMetamagic.AllowedType[] ItemTypes =
        {
            AutoMetamagic.AllowedType.FromScroll,
            AutoMetamagic.AllowedType.FromPotion
        };

        private static readonly DamageEnergyType[] AscendantElements =
        {
            DamageEnergyType.Cold, DamageEnergyType.Fire, DamageEnergyType.Electricity,
            DamageEnergyType.Acid, DamageEnergyType.Magic, DamageEnergyType.NegativeEnergy
        };

        private static readonly SpellDescriptor[] IgnoredImmunities =
        {
            SpellDescriptor.Poison, SpellDescriptor.Compulsion, SpellDescriptor.Death,
            SpellDescriptor.Daze, SpellDescriptor.Disease, SpellDescriptor.MindAffecting,
            SpellDescriptor.Nauseated, SpellDescriptor.Stun
        };

        public static void Configure()
        {
            Main.Log.Log("Calling the Configure Method");
            var feature = FeatureConfigurator.New(Feature, FeatureGuid)
                    .SetDisplayName("MnemonicDevice.FeatureName")
                    .SetDescription("MnemonicDevice.FeatureDescription")
                    .SetHideInUI(true);

                    foreach (var mm in AlwaysOn)
                    feature.AddAutoMetamagic(allowedAbilities: AutoMetamagic.AllowedType.Any, metamagic: mm);

                    // Quicken is restricted, so it stays separate
                    feature.AddAutoMetamagic(allowedAbilities: AutoMetamagic.AllowedType.SpellOrSpellLike, metamagic: Metamagic.Quicken);

            foreach (var mm in AlwaysOn)
                foreach (var item in ItemTypes)
                    feature.AddAutoMetamagic(allowedAbilities: item, metamagic: mm);

            foreach (var item in ItemTypes)
                feature.AddAutoMetamagic(allowedAbilities: item, metamagic: Metamagic.Quicken);

            foreach (var element in AscendantElements)
                        feature.AddAscendantElement(element: element);

                    foreach (var descriptor in IgnoredImmunities)
                        feature.AddIgnoreSpellImmunity(spellDescriptor: descriptor);

            feature
                    .AddComponent(new MyEnduringSpells())
                    .AddIgnoreConcealment()
                    .AddPrerequisiteNoFeature(FeatureRefs.EnduringSpells.ToString())
                    .AddPrerequisiteNoFeature(FeatureRefs.EnduringSpellsGreater.ToString())
                    .Configure();
        }

        internal static readonly string Feature = "MnemonicDevice";
        internal static readonly string FeatureName = "Mnemonic Device";
        internal static readonly string FeatureGuid = "DD81C2DD-DDF3-4567-AB07-39A2F5187B92";
        internal static readonly string FeatureDescription = "You have discovered ways to fortify your mind, enabling you to memorise more spells";
    }
}

