﻿using BlueprintCore.Blueprints.CustomConfigurators.Classes.Selection;
using BlueprintCore.Utils;
using HarmonyLib;
using Kingmaker.Blueprints.JsonSystem;
using Kingmaker.Enums;
using MyFeats.Feats;
using System.Reflection;
using System.Text;
using UnityModManagerNet;

namespace MyFeats;


public static class Main {
    internal static Harmony HarmonyInstance;
    internal static UnityModManager.ModEntry.ModLogger Log;

    internal static readonly WeaponCategory[] AllMeleeAndRangedCategories =
    Enum.GetValues(typeof(WeaponCategory))
        .Cast<WeaponCategory>()
        .ToArray();
   

    public static bool Load(UnityModManager.ModEntry modEntry) {
        Log = modEntry.Logger;
        modEntry.OnGUI = OnGUI;
        HarmonyInstance = new Harmony(modEntry.Info.Id);
        try {
            HarmonyInstance.PatchAll(Assembly.GetExecutingAssembly());
        } catch {
            HarmonyInstance.UnpatchAll(HarmonyInstance.Id);
            throw;
        }
        return true;
    }

    public static void OnGUI(UnityModManager.ModEntry modEntry) {

    }

    [HarmonyPatch(typeof(BlueprintsCache))]
    public static class BlueprintsCaches_Patch {
        private static bool Initialized = false;

        [HarmonyPriority(Priority.First)]
        [HarmonyPatch(nameof(BlueprintsCache.Init)), HarmonyPostfix]
        public static void Init_Postfix() {
            try {
                if (Initialized) {
                    Log.Log("Already initialized blueprints cache.");
                    return;
                }
                Initialized = true;

                Log.Log("Patching blueprints.");

                Log.Log("Loading Hardening...");
                HardeningFeat.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Mnemonic Device...");
                MnemonicDevice.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Magical Affinity (Strength)...");
                MagicalAffinityStr.Configure();
                Log.Log("Loaded");

                Log.Log("Loading Magical Affinity (Dexterity)...");
                MagicalAffinityDex.Configure();
                Log.Log("Loaded");

                Log.Log("Loading Magical Affinity (Constitution)...");
                MagicalAffinityCon.Configure();
                Log.Log("Loaded");

                Log.Log("Loading Magical Affinity (Intelligence)...");
                MagicalAffinityInt.Configure();
                Log.Log("Loaded");

                Log.Log("Loading Magical Affinity (Wisdom)...");
                MagicalAffinityWis.Configure();
                Log.Log("Loaded");

                Log.Log("Loading Magical Affinity (Charisma)...");
                MagicalAffinityCha.Configure();
                Log.Log("Loaded");

                Log.Log("Loading Protective Luck Buff...");
                MyProtectiveLuckBuff.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Combat Personality...");
                CombatPersonality.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Combat Analysis...");
                CombatAnalysis.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Combat Avoidance...");
                CombatAvoidance.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Combat Insight...");
                CombatInsight.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Combat Conditioning...");
                CombatConditioning.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Combat Prowess...");
                CombatProwess.Configure();
                Log.Log("Loaded.");

                Log.Log("Loading Advanced Combat Tactics...");
                AdvancedCombatTactics.Configure();
                Log.Log("Loaded.");

                FeatureSelectionConfigurator.For("247a4068296e8be42890143f451b4b45")
                .AddToAllFeatures(AdvancedCombatTactics.FeatureGuid)
                .Configure();

            } catch (Exception e) {
                Log.Log(string.Concat("Failed to initialize.", e));
            }
        }
    }
}
