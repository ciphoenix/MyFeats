﻿using BlueprintCore.Utils;
using Kingmaker.Blueprints.Classes;
using Kingmaker.EntitySystem.Entities;
using MyFeats.Feats;
using Kingmaker.UnitLogic;
using Kingmaker.UnitLogic.Buffs;
using Kingmaker.UnitLogic.Mechanics.Actions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyFeats.Patches
{
    internal static class MnemonicMarker
    {
        private static BlueprintFeature _bp;
        internal static BlueprintFeature Blueprint =>
            _bp ??= BlueprintTool.Get<BlueprintFeature>(MnemonicDevice.FeatureGuid);

        internal static bool Has(UnitEntityData unit) =>
            unit != null && unit.Descriptor.HasFact(Blueprint);
    }
}
